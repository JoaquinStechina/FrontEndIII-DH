import React from "react";
import Registro from "./Registro"

function App(){
  return(
    <Registro/>
  )
}

export default App;